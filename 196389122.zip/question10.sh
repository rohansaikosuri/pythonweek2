git checkout main
git merge branch1 
