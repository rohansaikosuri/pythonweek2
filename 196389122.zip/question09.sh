git checkout -b branch1
touch file3
git add file3
git commit -m "branching"
git push
