mkdir dir1
touch file2
git add dir1
