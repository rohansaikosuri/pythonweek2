git add .
git commit -m "ques6"
git push 
