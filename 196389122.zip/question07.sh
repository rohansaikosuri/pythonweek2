git add *.py
git commit -m "python_files"
git push
