git checkout branch2
git stash pop
git add .
git commit -m "unstatsh"
git push
