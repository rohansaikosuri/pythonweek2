touch file3.txt
git add file3.txt
