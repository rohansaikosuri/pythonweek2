git clone https://github.com/ian-knight-uofa/git-practice-04.git
git fetch origin update1
git checkout update1

