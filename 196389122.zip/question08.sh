mkdir dir2
mv *.txt dir2
git add .  
git commit -m "move_files"
git push
